import java.io.PrintStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class CMD{
    private static PrintStream o=System.out;
    
	public static void main(String[] a){
		String command="ping google.com";
        StringBuffer output = new StringBuffer();
 
		Process p;
		try {
			p = Runtime.getRuntime().exec(command);
			//p.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), "Cp850"));
			BufferedWriter writer = new BufferedWriter(new FileWriter("Output.txt"));
            String line = "";			
			while ((line = reader.readLine())!= null) {
				output.append(line + "\n");
				writer.append(line + "\n");
			}
			writer.close();
 
		} catch (Exception e) {
			e.printStackTrace();
		}
 
		o.println(output.toString());
	
	}
	
	public static String execute(String cmd){
		String command=cmd;
        StringBuffer output = new StringBuffer();
 
		Process p;
		try {
			p = Runtime.getRuntime().exec(command);
			//p.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), "Cp850"));
            String line = "";			
			while ((line = reader.readLine())!= null) {
				output.append(line + "\n");
			}
 
		} catch (Exception e) {
			e.printStackTrace();
		}
 
		return output.toString();
	
	}
	
	public static void printOutput(String input){
	    try{
			BufferedWriter writer = new BufferedWriter(new FileWriter("Output.txt"));
		
			writer.write(input);
			writer.close();
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*    public static void main(String[] a){
		String command="ping google.com";
        StringBuffer output = new StringBuffer();
 
		Process p;
		try {
			p = Runtime.getRuntime().exec(command);
			//p.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = "";			
			while ((line = reader.readLine())!= null) {
				output.append(line + "\n");
			}
 
		} catch (Exception e) {
			e.printStackTrace();
		}
 
		o.println(output.toString());
    }*/
    
    
}
