import java.io.PrintStream;

public abstract class Zeichen{
    
    public Zeichen(){
    }

    public boolean isVisible(){
        return false;
    }
}
