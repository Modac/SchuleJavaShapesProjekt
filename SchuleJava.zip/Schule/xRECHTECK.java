import java.awt.*;

/**
 * A square that can be manipulated and that draws itself on a canvas.
 * 
 */

public class xRECHTECK
{
    private int seite1;
    private int seite2;
	private int w;
    private int xPosition;
    private int yPosition;
    private String farbe;
	private Color color;
    private boolean istSichtbar;

    /**
     * Create a new square at default position with default color.
     */
    public xRECHTECK()
    {
        seite1 = 30;
        seite2 = 20;
        xPosition = 60;
        yPosition = 50;
        farbe = "red";
        istSichtbar = false;
        w=0;
    }
    
    public xRECHTECK(int breite,int hoehe, int xPos, int yPos, String farbe)
    {
        seite1 = breite;
        seite2 = hoehe;
        xPosition = xPos;
        yPosition = yPos;
        this.farbe = farbe;
        istSichtbar = false;
		w=0;
    }

	public xRECHTECK(int breite,int hoehe, int xPos, int yPos, int winkel, String farbe)
    {
        seite1 = breite;
        seite2 = hoehe;
        xPosition = xPos;
        yPosition = yPos;
        this.farbe = farbe;
        istSichtbar = false;
		w=winkel;
    }
	
	public xRECHTECK(int breite,int hoehe, int xPos, int yPos, int winkel, Color color)
    {
        seite1 = breite;
        seite2 = hoehe;
        xPosition = xPos;
        yPosition = yPos;
        this.color =color;
        istSichtbar = false;
		w=winkel;
    }
	
    /**
     * Make this square visible. If it was already visible, do nothing.
     */
    public void zeichne()
    {
        istSichtbar = true;
        draw();
    }
	
	public void zeichne(oCanvas canvas){
        istSichtbar = true;
        draw(canvas);
    }
    
    /**
     * Make this square invisible. If it was already invisible, do nothing.
     */
    public void loesche(oCanvas canvas){
        erase(canvas);
        istSichtbar = false;
    }
	
	public void loesche()
    {
        erase();
        istSichtbar = false;
    }
    
    /**
     * Move the square a few pixels to the right.
     */
    public void verschiebeRechts()
    {
        verschiebeHorizontal(20);
    }

    /**
     * Move the square a few pixels to the left.
     */
    public void verschiebeLinks()
    {
        verschiebeHorizontal(-20);
    }

    /**
     * Move the square a few pixels up.
     */
    public void verschiebeOben()
    {
        verschiebeVertikal(-20);
    }

    /**
     * Move the square a few pixels down.
     */
    public void cherschiebeUnten()
    {
        verschiebeVertikal(20);
    }

    /**
     * Move the square horizontally by 'distance' pixels.
     */
    public void verschiebeHorizontal(int distanz)
    {
        erase();
        xPosition = xPosition + distanz;
        draw();
    }

    /**
     * Move the square vertically by 'distance' pixels.
     */
    public void verschiebeVertikal(int distanz)
    {
        erase();
        yPosition = yPosition + distanz;
        draw();
    }

    /**
     * Slowly move the square horizontally by 'distance' pixels.
     */
    public void langsamVerschiebenHorizontal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            xPosition = xPosition + delta;
            draw();
        }
    }

    /**
     * Slowly move the square vertically by 'distance' pixels.
     */
    public void langsamVerschiebenVertikal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            yPosition = yPosition + delta;
            draw();
        }
    }

    /**
     * Change the size to the new size (in pixels). Size must be >= 0.
     */
    public void aendereBreite(int neueBreite)
    {
        erase();
        seite1 = neueBreite;
        draw();
    }

    public void aendereHoehe(int neueHoehe)
    {
        erase();
        seite2 = neueHoehe;
        draw();
    }
    
    /**
     * Change the color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void aendereFarbe(String neueFarbe)
    {
        color=null;
        farbe = neueFarbe;
        draw();
    }
	
	public void aendereFarbe(Color neueFarbe)
    {
        farbe=null;
        color = neueFarbe;
        draw();
    }

    /*
     * Draw the square with current specifications on screen.
     */
    private void draw()
    {
		try{
			if(istSichtbar) {
				Canvas canvas = Canvas.getCanvas();
				canvas.draw(this, farbe, new Polygon(getxPoints(), getyPoints(), 4));
				canvas.wait(1);
			}
		} catch(Exception ignored){}
		
		try{
			if(istSichtbar) {
				Canvas canvas = Canvas.getCanvas();
				canvas.draw(this, color, new Polygon(getxPoints(), getyPoints(), 4));
				canvas.wait(1);
			}
		} catch(Exception ignored){}
    }
	
	private void draw(oCanvas canvas){
		try{
			if(istSichtbar) {
				canvas.draw(this, farbe, new Polygon(getxPoints(), getyPoints(), 4));
				canvas.wait(1);
			}
		} catch(Exception ignored){}
		
		try{
			if(istSichtbar) {
				canvas.draw(this, color, new Polygon(getxPoints(), getyPoints(), 4));
				canvas.wait(1);
			}
		} catch(Exception ignored){}
    }
	
	private int[] getxPoints(){
		int[] xP=new int[4];
		
		int x=seite1/2;
		int c=seite2/2;
		
		xP[0]=(int)(xPosition+x+sin(w)*c-cos(w)*x);
		xP[1]=(int)(xP[0]-sin(w)*c*2);
		xP[2]=(int)(xP[1]+cos(w)*x*2);
		xP[3]=(int)(xP[0]+cos(w)*x*2);
		
		return xP;
	}
	
	private int[] getyPoints(){
		int[] yP=new int[4];
		
		int x=seite1/2;
		int c=seite2/2;
		
		yP[0]=(int)(yPosition+c-cos(w)*c-sin(w)*x);
		yP[1]=(int)(yP[0]+cos(w)*c*2);
		yP[2]=(int)(yP[1]+sin(w)*x*2);
		yP[3]=(int)(yP[0]+sin(w)*x*2);
		
		return yP;
	}

    /*
     * Erase the square on screen.
     */
    private void erase()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
	
	private void erase(oCanvas canvas){
        if(istSichtbar) {
			canvas.erase(this);
        }
    }
    
    public void setX(int xPosition){
        erase();
        this.xPosition=xPosition;
        draw();
	}
	
	public void setY(int yPosition){
	    erase();
	    this.yPosition=yPosition;
	    draw();
	}
	
	public void setPos(int xPosition, int yPosition){
	    erase();
	    this.xPosition=xPosition;
	    this.yPosition=yPosition;
	    draw();
	}
	
	public void setAngle(int angle){
		erase();
		w=angle;
		draw();
	}
	
	public int getX(){
		return xPosition;
	}
	
	public int getY(){
		return yPosition;
	}
	
	public int getAngle(){
		return w;
	}
	
	private double sin(int w){
		return Math.sin(Math.PI/180*(double)w);
	}
	
	private double cos(int w){
		return Math.cos(Math.PI/180*(double)w);
	}
	
	public boolean isVisible(){
		return istSichtbar;
	}
	
	public boolean contains(int x, int y){
		Polygon pol=new Polygon(getxPoints(), getyPoints(), 4);
		return pol.contains(x,y);
	}
}