import java.io.PrintStream;
import java.awt.Color;

public class KREUZ extends Zeichen{
	private static PrintStream o=System.out;
	
	private xRECHTECK[] linien;
	private int size, width;
	private Color color;
	private int xPos,yPos;
	private boolean istSichtbar;
	
	public KREUZ(){
		linien=new xRECHTECK[2];
		size = 50;
		width = 5;
		xPos=50;
		yPos=50;
		color=Color.red;
		
		linien[0]=new xRECHTECK(width, size, xPos+size/2-width/2, yPos, 45,color);
		linien[1]=new xRECHTECK(width, size, xPos+size/2-width/2, yPos, -45,color);
	}
	
	public KREUZ(int size, int width, int xPos, int yPos, Color color){
		this.linien=new xRECHTECK[2];
		this.size = size;
		this.width = width;
		this.xPos=xPos;
		this.yPos=yPos;
		this.color=color;
		
		linien[0]=new xRECHTECK(width, size, xPos+size/2-width/2, yPos, 45,color);
		linien[1]=new xRECHTECK(width, size, xPos+size/2-width/2, yPos, -45,color);
	}
	
	public void zeichne(){
		
		linien[0].zeichne();
		linien[1].zeichne();
		istSichtbar=true;
	}
	
	public void zeichne(oCanvas canvas){
		
		linien[0].zeichne(canvas);
		linien[1].zeichne(canvas);
		istSichtbar=true;
	}
	
	public void loesche(){
		linien[0].loesche();
		linien[1].loesche();
		istSichtbar=false;
	}
	
	public void loesche(oCanvas canvas){
		linien[0].loesche(canvas);
		linien[1].loesche(canvas);
		istSichtbar=false;
	}
	
	public boolean isVisible(){
		return istSichtbar;
	}
}
