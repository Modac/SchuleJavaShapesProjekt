import java.io.PrintStream;

public class TEST{
	private static PrintStream o=System.out;
	
	xRECHTECK[] rs;
	int xPos,yPos, width, height;
	
	public TEST(){
		Canvas.getSecretCanvas(1000,700);
		
		rs= new xRECHTECK[18];
		xPos=500;
		yPos=100;
		width=10;
		height=500;
		
		for(int i=0;i<rs.length;i++){
			rs[i]=new xRECHTECK(width, height, xPos, yPos, i*10, ColorTools.getRandomColor());
			
		}
	}
	
	public TEST(int width, int height, int xPos, int yPos){
		Canvas.getSecretCanvas(1000,700);
		
		rs= new xRECHTECK[18];
		this.xPos=xPos;
		this.yPos=yPos;
		this.width=width;
		this.height=height;
		for(int i=0;i<rs.length;i++){
			rs[i]=new xRECHTECK(width, height, xPos, yPos, i*10, ColorTools.getRandomColor());
			
		}
	}
	
	public void draw(){
		for(int i=0;i<rs.length;i++){
			rs[i].zeichne();
			wait(100);
		}
	}
	
	public void setX(int x){
		xPos=x;
		for(int i=0;i<rs.length;i++){
			rs[i].setX(xPos);
		}
	}
	
	public void setY(int y){
		yPos=y;
		for(int i=0;i<rs.length;i++){
			rs[i].setY(yPos);
		}
	}
	
	public void setPos(int x, int y){
		xPos=x;
		yPos=y;
		for(int i=0;i<rs.length;i++){
			rs[i].setPos(xPos,yPos);
		}
	}
	
	public void setWidth(int width){
		this.width=width;
		for(int i=0;i<rs.length;i++){
			rs[i].aendereBreite(width);
		}
	}
	
	public void setHeight(int height){
		this.height=height;
		for(int i=0;i<rs.length;i++){
			rs[i].aendereHoehe(height);
		}
	}
	
	private void wait(int milliseconds)
    {
        try{
            Thread.sleep(milliseconds);
        } catch (Exception e){
           System.out.println(e);
        }
    }
}
