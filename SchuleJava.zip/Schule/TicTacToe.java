import java.io.PrintStream;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class TicTacToe implements MouseListener {
    private static PrintStream o=System.out;
    
    KREUZ[][] kreuze;
    RING[][] ringe;
    xRECHTECK[] grenzen;
    xRECHTECK[][] felder;
    oCanvas canvas;
    int pressedX, pressedY;
    int zug;
    
    public TicTacToe(){
        
        kreuze=new KREUZ[3][3];
        ringe=new RING[3][3];
        felder=new xRECHTECK[3][3];
        grenzen=new xRECHTECK[4];
        
        canvas=new oCanvas("TicTacToe", 330, 330, Color.white);
        canvas.setResizable(false);
        canvas.wait(10);
        canvas.pack();
		canvas.setMiddlePos();
        
        //o.println(felder.length+"");
        //o.println(felder[0].length+"[]");
        
        for(int i=0;i<felder.length;i++){
            int x=i*(100+5)+10; // xPos = i * (width of fields + width of borders) + environmental border width
            for(int m=0;m<felder[i].length;m++){
                int y=m*(100+5)+10; // same as for xPos
                kreuze[i][m]=new KREUZ(100, 10, x, y, Color.RED);
                ringe[i][m]=new RING(100, 10, x-1, y-1, "blue");
                felder[i][m]=new xRECHTECK(100, 100, x, y, 0, new Color(0,0,0,0));
            }
        }
        for(int i=0;i<grenzen.length;i++){
            if(i%2==1) grenzen[i]=new xRECHTECK(5, felder[0].length*(100+5)-5, (i/2+1)*(100+5)+5, 10, 0, Color.black);
            else grenzen[i]=new xRECHTECK(felder[0].length*(100+5)-5, 5, 10, (i/2+1)*(100+5)+5, 0 ,Color.black);
        }
        
        canvas.getoCanvasPane().addMouseListener(this);
    }
    
    public void init(){
        canvas.setVisible(true);
        for(int i=0;i<felder.length;i++){
            for(int m=0;m<felder[i].length;m++){
                felder[i][m].zeichne(canvas);
            }
        }
        for(int i=0;i<grenzen.length;i++){
            grenzen[i].zeichne(canvas);
        }
    }
    
    /*public void draw(){
        canvas.setVisible(true);
        for(int i=0;i<felder.length;i++){
            for(int m=0;m<felder[i].length;m++){
                kreuze[i][m].zeichne(canvas);
                ringe[i][m].zeichne(canvas);
                felder[i][m].zeichne(canvas);
            }
        }
        
    }*/
    
    private void checkArea(int x, int y){
        for(int i=0;i<felder.length;i++){
            for(int m=0;m<felder[i].length;m++){
            //o.println(( kreuze[i][m].isVisible() || ringe[i][m].isVisible() ));
                if( !(kreuze[i][m].isVisible() || ringe[i][m].isVisible()) && felder[i][m].contains(pressedX, pressedY) && felder[i][m].contains(x,y) ){
                    //if( !(kreuze[i][m].isVisible() || ringe[i][m].isVisible()) ){
                        zug++;
                        if  (zug%2==1)kreuze[i][m].zeichne(canvas);
                        else ringe[i][m].zeichne(canvas);
                        
						try{isSomeoneWinner();}catch(NoSuchFieldException e){}
                        break;
                    //}
                }
            }
        }
        //o.println("-----");
    }
	
	private void isSomeoneWinner() throws NoSuchFieldException{
		WINNER winner=null;
		boolean won=false;
		if(checkWin(kreuze).isWinner()) {
		    winner=checkWin(kreuze);
		    won=true;
			
		}
		else if(checkWin(ringe).isWinner()) {
		    winner=checkWin(ringe);
		    won=true;
		}
		if(winner!=null){
			if(won && winner.getZeichen()==kreuze)o.println("Kreuze hat gewonnen an: ");
			if(won && winner.getZeichen()==ringe)o.println("Ringe hat gewonnen an: ");
		
			for(int i=0;i<winner.getXPos().length;i++){
				o.print(winner.getXPos()[i]+"|"+winner.getYPos()[i]);
			}
		}
	}
    
    private WINNER checkWin(Zeichen[][] zeichen){
        WINNER winner=new WINNER(zeichen, null, null, false);
		for(int i=0;i<felder.length;i++){
		winner.isWinner(true);
			winner.setPos(null, null);
			for(int m=0;m<felder.length;m++){
				if(winner.isWinner()){
					if(zeichen[i][m].isVisible()) {
					
						winner.isWinner(true);
						winner.addXPos(i);
						winner.addYPos(m);
						//o.print(winner.getZeichen().getClass().getSimpleName());
						//winner.printPos();
					}
					else winner.isWinner(false);
					//o.println("i|m: "+i+"|"+m+" is Winning: "+isWinning+" isVisible: "+zeichen[i][m].isVisible());
				}
			}
			if(winner.isWinner()) return winner;
		}
		for(int m=0;m<felder.length;m++){
			winner.isWinner(true);
			winner.setPos(null, null);
			for(int i=0;i<felder.length;i++){
				if(winner.isWinner()){
					if(zeichen[i][m].isVisible()){
						
						winner.isWinner(true);
						winner.addXPos(i);
						winner.addYPos(m);
						//o.print(winner.getZeichen().getClass().getSimpleName());
						//winner.printPos();
					}
					else winner.isWinner(false);
				}
			}
			if(winner.isWinner()) return winner;
		}
		
		// In Queue for Improvment // IQfI
		
		if(zeichen[0][0].isVisible() && zeichen[1][1].isVisible() && zeichen[2][2].isVisible()) return new WINNER(zeichen, new int[]{0,1,2}, new int[]{0,1,2}, true );
		if(zeichen[2][0].isVisible() && zeichen[1][1].isVisible() && zeichen[0][2].isVisible()) return new WINNER(zeichen, new int[]{2,1,0}, new int[]{0,1,2}, true );

		return new WINNER(zeichen, new int[]{0}, new int[]{0}, false );
    }
    
    public void newGame(){
        for(int i=0;i<felder.length;i++){
            for(int m=0;m<felder[i].length;m++){
                kreuze[i][m].loesche(canvas);
                ringe[i][m].loesche(canvas);
            }
        }
		zug=0;
    }
    
    public void mouseClicked(MouseEvent e){
        //o.println("Mouse Clicked at: "+ e.getX()+" / "+e.getY());
    }
    
    public void mouseEntered(MouseEvent e){
        
    }
    
    public void mouseExited(MouseEvent e){
        
    }
    
    public void mousePressed(MouseEvent e){
        //o.println("Mouse Pressed at: "+ e.getX()+" / "+e.getY());
        pressedX=e.getX();
        pressedY=e.getY();
    }
    
    public void mouseReleased(MouseEvent e){
        //o.println("Mouse Released at: "+ e.getX()+" / "+e.getY());
		checkArea(e.getX(), e.getY());
	}
	
	private class WINNER{
		private Zeichen[][] zeichen;
		private int[] xPos, yPos;
		private boolean isWinner;
		
		public WINNER(Zeichen[][] zeichen, int[] xPos, int[] yPos, boolean isWinner){
			this.zeichen=zeichen;
			this.xPos=xPos;
			this.yPos=yPos;
			this.isWinner=isWinner;
		}
		
		public WINNER(Zeichen[][] zeichen, boolean isWinner){
			this.zeichen=zeichen;
			this.isWinner=isWinner;
		}
		
		public Zeichen[][] getZeichen(){
			return zeichen;
		}
		
		public int[] getXPos(){
			return xPos;
		}
		
		public int[] getYPos(){
			return yPos;
		}
		
		public boolean isWinner(){
			return isWinner;
		}
		
		public void isWinner(boolean isWinner){
			this.isWinner=isWinner;
		}
		
		public void setXPos(int[] xPos){
			this.xPos=xPos;
		}
		
		public void setYPos(int[] yPos){
			this.yPos=yPos;
		}
		
		public void setPos(int[] xPos, int[] yPos){
			this.xPos=xPos;
			this.yPos=yPos;
		}
		
		public void addXPos(int xpos){
			int[] temp;
			try{
				temp= new int[xPos.length+1];
				for(int i=0; i<xPos.length;i++){
					temp[i]=xPos[i];
				}
				temp[xPos.length]=xpos;
			} catch(NullPointerException e){
				temp=new int[]{xpos};
			}
				
			xPos=temp;
		}
		
		public void addYPos(int ypos){
		    int[] temp;
			try{
				temp= new int[yPos.length+1];
				for(int i=0; i<yPos.length;i++){
					temp[i]=yPos[i];
				}
				temp[yPos.length]=ypos;
			} catch(NullPointerException e){
				temp=new int[]{ypos};
			}
			
			yPos=temp;
			
		}
		
		public void printPos(){
		try{
			for(int i=0;i<xPos.length;i++){
				o.print(i+1+") "+xPos[i]+"|"+yPos[i]+"\n");
			}
		}catch(Exception e){}
		o.println();
		}
	}
}
