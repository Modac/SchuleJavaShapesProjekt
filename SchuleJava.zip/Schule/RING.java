import java.awt.*;
import java.awt.geom.*;



public class RING extends Zeichen
{
    private int durchmesser;
    private int xPosition;
    private int yPosition, breite;
    private String farbe;
    private boolean istSichtbar;
    
    /**
     * Create a new circle at default position with default color.
     */
    public RING()
    {
        durchmesser = 30;
        xPosition = 20;
        yPosition = 60;
        farbe = "blue";
		breite = 5;
        istSichtbar = false;
    }

	
	public RING(int durchmesser, int breite, int xPosition, int yPosition, String farbe){
        this.durchmesser = durchmesser;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
		this.breite=breite;
        this.farbe = farbe;
        istSichtbar = false;
    }
    /**
     * Make this circle visible. If it was already visible, do nothing.
     */
    public void zeichne()
    {
        istSichtbar = true;
        draw();
    }
	
	public void zeichne(oCanvas canvas){
        istSichtbar = true;
        draw(canvas);
    }
    
    /**
     * Make this circle invisible. If it was already invisible, do nothing.
     */
    public void loesche()
    {
        erase();
        istSichtbar = false;
    }
	
	public void loesche(oCanvas canvas){
        erase(canvas);
        istSichtbar = false;
    }
    
    /**
     * Move the circle a few pixels to the right.
     */
    public void verschiebeRechts()
    {
        verschiebeHorizontal(20);
    }

    /**
     * Move the circle a few pixels to the left.
     */
    public void verschiebeLinks()
    {
        verschiebeHorizontal(-20);
    }

    /**
     * Move the circle a few pixels up.
     */
    public void verschiebeOben()
    {
        verschiebeVertikal(-20);
    }

    /**
     * Move the circle a few pixels down.
     */
    public void verschiebeUnten()
    {
        verschiebeVertikal(20);
    }

    /**
     * Move the circle horizontally by 'distance' pixels.
     */
    public void verschiebeHorizontal(int distanz)
    {
        erase();
        xPosition = xPosition + distanz;
        draw();
    }

    /**
     * Move the circle vertically by 'distance' pixels.
     */
    public void verschiebeVertikal(int distance)
    {
        erase();
        yPosition = yPosition + distance;
        draw();
    }

    /**
     * Slowly move the circle horizontally by 'distance' pixels.
     */
    public void langsamVerschiebenHorizontal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            xPosition = xPosition + delta;
            draw();
        }
    }

    /**
     * Slowly move the circle vertically by 'distance' pixels.
     */
    public void langsamVerschiebenVertikal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            yPosition = yPosition + delta;
            draw();
        }
    }

    /**
     * Change the size to the new size (in pixels). Size must be >= 0.
     */
    public void aendereGroesse(int neuerDurchmesser)
    {
        erase();
        durchmesser = neuerDurchmesser;
        draw();
    }

    /**
     * Change the color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void aendereFarbe(String neueFarbe)
    {
        farbe = neueFarbe;
        draw();
    }

    /*
     * Draw the circle with current specifications on screen.
     */
    private void draw()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
			Ellipse2D.Double ell2 = new Ellipse2D.Double(xPosition+breite, yPosition+breite, durchmesser-2*breite, durchmesser-2*breite);
			Ellipse2D.Double ell1 = new Ellipse2D.Double(xPosition, yPosition, durchmesser, durchmesser);
			Area ring= new Area(ell1);
			ring.subtract(new Area(ell2));
            canvas.draw(this, farbe, ring);
            canvas.wait(1);
        }
    }
	
	private void draw(oCanvas canvas)
    {
        if(istSichtbar) {
			Ellipse2D.Double ell2 = new Ellipse2D.Double(xPosition+breite, yPosition+breite, durchmesser-2*breite, durchmesser-2*breite);
			Ellipse2D.Double ell1 = new Ellipse2D.Double(xPosition, yPosition, durchmesser, durchmesser);
			Area ring= new Area(ell1);
			ring.subtract(new Area(ell2));
            canvas.draw(this, farbe, ring);
            canvas.wait(1);
        }
    }

    /*
     * Erase the circle on screen.
     */
    private void erase()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
	
	private void erase(oCanvas canvas){
        if(istSichtbar) {
            canvas.erase(this);
        }
    }
    
    public void setX(int xPosition){
        erase();
        this.xPosition=xPosition;
        draw();
    }
    
    public void setY(int yPosition){
        erase();
        this.yPosition=yPosition;
        draw();
    }
    
    public void setPos(int xPosition, int yPosition){
        erase();
        this.xPosition=xPosition;
        this.yPosition=yPosition;
        draw();
    }
    
    public int getDurchmesser(){
        return durchmesser;
    }
    
    public int getX(){
	    return xPosition;
	}
	
	public int getY(){
	    return yPosition;
	}
	
	public boolean isVisible(){
		return istSichtbar;
	}
}




/*import java.io.PrintStream;

public class RING{
    private static PrintStream o=System.out;
	
	RING[] kr;
	
	public RING(){
}*/
