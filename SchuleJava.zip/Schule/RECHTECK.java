import java.awt.*;

/**
 * A square that can be manipulated and that draws itself on a canvas.
 * 
 */

public class RECHTECK
{
    private int seite1;
    private int seite2;
    private int xPosition;
    private int yPosition;
    private String farbe;
    private boolean istSichtbar;

    /**
     * Create a new square at default position with default color.
     */
    public RECHTECK()
    {
        seite1 = 30;
        seite2 = 20;
        xPosition = 60;
        yPosition = 50;
        farbe = "red";
        istSichtbar = false;
    }
    
    public RECHTECK(int breite,int hoehe, int xPos, int yPos, String farbe)
    {
        seite1 = breite;
        seite2 = hoehe;
        xPosition = xPos;
        yPosition = yPos;
        this.farbe = farbe;
        istSichtbar = false;
    }

    /**
     * Make this square visible. If it was already visible, do nothing.
     */
    public void zeichne()
    {
        istSichtbar = true;
        draw();
    }
    
    /**
     * Make this square invisible. If it was already invisible, do nothing.
     */
    public void loesche()
    {
        erase();
        istSichtbar = false;
    }
    
    /**
     * Move the square a few pixels to the right.
     */
    public void verschiebeRechts()
    {
        verschiebeHorizontal(20);
    }

    /**
     * Move the square a few pixels to the left.
     */
    public void verschiebeLinks()
    {
        verschiebeHorizontal(-20);
    }

    /**
     * Move the square a few pixels up.
     */
    public void verschiebeOben()
    {
        verschiebeVertikal(-20);
    }

    /**
     * Move the square a few pixels down.
     */
    public void cherschiebeUnten()
    {
        verschiebeVertikal(20);
    }

    /**
     * Move the square horizontally by 'distance' pixels.
     */
    public void verschiebeHorizontal(int distanz)
    {
        erase();
        xPosition = xPosition + distanz;
        draw();
    }

    /**
     * Move the square vertically by 'distance' pixels.
     */
    public void verschiebeVertikal(int distanz)
    {
        erase();
        yPosition = yPosition + distanz;
        draw();
    }

    /**
     * Slowly move the square horizontally by 'distance' pixels.
     */
    public void langsamVerschiebenHorizontal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            xPosition = xPosition + delta;
            draw();
        }
    }

    /**
     * Slowly move the square vertically by 'distance' pixels.
     */
    public void langsamVerschiebenVertikal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            yPosition = yPosition + delta;
            draw();
        }
    }

    /**
     * Change the size to the new size (in pixels). Size must be >= 0.
     */
    public void aendereBreite(int neueBreite)
    {
        erase();
        seite1 = neueBreite;
        draw();
    }

    public void aendereHoehe(int neueHoehe)
    {
        erase();
        seite2 = neueHoehe;
        draw();
    }
    
    /**
     * Change the color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void aendereFarbe(String neueFarbe)
    {
        
        farbe = neueFarbe;
        draw();
    }

    /*
     * Draw the square with current specifications on screen.
     */
    private void draw()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, farbe,
                        new Rectangle(xPosition, yPosition, seite1, seite2));
            canvas.wait(10);
        }
    }

    /*
     * Erase the square on screen.
     */
    private void erase()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    public void xPositionAendern(int xPosition){
        erase();
        this.xPosition=xPosition;
        draw();
	}
	
	public void yPositionAendern(int yPosition){
	    erase();
	    this.yPosition=yPosition;
	    draw();
	}
	
	public void x_yPositionAendern(int xPosition, int yPosition){
	    erase();
	    this.xPosition=xPosition;
	    this.yPosition=yPosition;
	    draw();
	}
	
	public boolean isVisible(){
		return istSichtbar;
	}
}