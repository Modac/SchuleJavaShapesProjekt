import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * oCanvas is a class to allow for simple graphical drawing on a oCanvas.
 * This is a modification of the general purpose oCanvas, specially made for
 * the BlueJ "shapes" example. 
 *
 * @author: Bruce Quig
 * @author: Michael Kolling (mik)
 *
 * @version: 1.6 (shapes)
 */
public class oCanvas
{
    // Note: The implementation of this class (specifically the handling of
    // shape identity and colors) is slightly more complex than necessary. This
    // is done on purpose to keep the interface and instance fields of the
    // shape objects in this project clean and simple for educational purposes.

    private static oCanvas oCanvasSingleton;

    /**
     * Factory method to get the oCanvas singleton object.
     */
    public static oCanvas getoCanvas(int width, int height)
    {
        if(oCanvasSingleton == null) {
            oCanvasSingleton = new oCanvas("BlueJ Shapes Demo", width, height, 
                                         Color.white);
        }
        oCanvasSingleton.setVisible(true);
        return oCanvasSingleton;
    }
	
	public static oCanvas getSecretoCanvas(int width, int height)
    {
        if(oCanvasSingleton == null) {
            oCanvasSingleton = new oCanvas("BlueJ Shapes Demo", width, height, 
                                         Color.white);
        }
        return oCanvasSingleton;
    }
    
    public static oCanvas getoCanvas()
    {
        if(oCanvasSingleton == null) {
            oCanvasSingleton = new oCanvas("BlueJ Shapes Demo", 300, 300, 
                                         Color.white);
        }
        oCanvasSingleton.setVisible(true);
        return oCanvasSingleton;
    }

    public static oCanvas getoCanvas(String t, int h, int w, Color c)
{
        if(oCanvasSingleton == null) {
            oCanvasSingleton = new oCanvas(t, h, w, c);
        }
        oCanvasSingleton.setVisible(true);
        return oCanvasSingleton;
    }
    
    public static oCanvas getoCanvas(int h, int w, Color c)
{
        if(oCanvasSingleton == null) {
            oCanvasSingleton     = new oCanvas("BlueJ Shapes Demo", h, w, c);
        }
        oCanvasSingleton.setVisible(true);
        return oCanvasSingleton;
    }
    
    public static void removeoCanvas(){
		if(oCanvasSingleton!=null){
			oCanvasSingleton.setVisible(false);
			oCanvasSingleton=null;
		}
    }
    
    public static void clearoCanvas(){
		oCanvasSingleton.setVisible(false);
        oCanvasSingleton=new oCanvas(oCanvasSingleton.getTitle(), oCanvasSingleton.getWidth(), oCanvasSingleton.getHeight(), oCanvasSingleton.getColor());
		oCanvasSingleton.setVisible(true);
    }
	
	public static void redrawoCanvas(){
		oCanvasSingleton.redraw();
	}
    //  ----- instance part -----

    private JFrame frame;
    private oCanvasPane oCanvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image oCanvasImage;
    private List objects;
    private HashMap shapes;
    
    private String title;
    private int width, height;
    private Color color;
    
    /**
     * Create a oCanvas.
     * @param title  title to appear in oCanvas Frame
     * @param width  the desired width for the oCanvas
     * @param height  the desired height for the oCanvas
     * @param bgClour  the desired background colour of the oCanvas
     */
    protected oCanvas(String title, int width, int height, Color bgColour)
    {
        frame = new JFrame();
        oCanvas = new oCanvasPane();
        frame.setContentPane(oCanvas);
        frame.setTitle(title);
        oCanvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList();
        shapes = new HashMap();
        
        this.title=title;
        this.width=width;
        this.height=height;
        color=bgColour;
    }
    
	
    public oCanvasPane getoCanvasPane(){
        return oCanvas;
    }

    /**
     * Set the oCanvas visibility and brings oCanvas to the front of screen
     * when made visible. This method can also be used to bring an already
     * visible oCanvas to the front of other windows.
     * @param visible  boolean value representing the desired visibility of
     * the oCanvas (true or false) 
     */
    public void setVisible(boolean visible)
    {
        if(graphic == null) {
            // first time: instantiate the offscreen image and fill it with
            // the background colour
            Dimension size = oCanvas.getSize();
            oCanvasImage = oCanvas.createImage(size.width, size.height);
            graphic = (Graphics2D)oCanvasImage.getGraphics();
			graphic.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    /**
     * Draw a given shape onto the oCanvas.
     * @param  referenceObject  an object to define identity for this shape
     * @param  color            the color of the shape
     * @param  shape            the shape object to be drawn on the oCanvas
     */
     // Note: this is a slightly backwards way of maintaining the shape
     // objects. It is carefully designed to keep the visible shape interfaces
     // in this project clean and simple for educational purposes.
    public void draw(Object referenceObject, String color, Shape shape)
    {
        objects.remove(referenceObject);   // just in case it was already there
        objects.add(referenceObject);      // add at the end
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }
	
	public void draw(Object referenceObject, Color color, Shape shape)
    {
        objects.remove(referenceObject);   // just in case it was already there
        objects.add(referenceObject);      // add at the end
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }
	
	public void drawText(Object referenceObject, String text,  Font font, int xPos, int yPos, Color color){
        objects.remove(referenceObject);   // just in case it was already there
        objects.add(referenceObject);      // add at the end
        shapes.put(referenceObject, new TextDescription( text,  font, xPos, yPos, color));
        redraw();
    }
 
    /**
     * Erase a given shape's from the screen.
     * @param  referenceObject  the shape object to be erased 
     */
    public void erase(Object referenceObject)
    {
        objects.remove(referenceObject);   // just in case it was already there
        shapes.remove(referenceObject);
        redraw();
    }

    /**
     * Set the foreground colour of the oCanvas.
     * @param  newColour   the new colour for the foreground of the oCanvas 
     */
    public void setForegroundColor(String colorString)
    {
        if(colorString.equals("red"))
            graphic.setColor(Color.red);
        else if(colorString.equals("black"))
            graphic.setColor(Color.black);
        else if(colorString.equals("blue"))
            graphic.setColor(Color.blue);
        else if(colorString.equals("yellow"))
            graphic.setColor(Color.yellow);
        else if(colorString.equals("green"))
            graphic.setColor(Color.green);
        else if(colorString.equals("magenta"))
            graphic.setColor(Color.magenta);
        else if(colorString.equals("white"))
            graphic.setColor(Color.white);
        else if(colorString.equals("gray"))
            graphic.setColor(Color.gray);
        else
            graphic.setColor(Color.black);
    }
    
    
    public void setForegroundColor(int r,int g, int b){
        graphic.setColor(new Color(r,g,b));
    }
     
    public void setForegroundColor(int r,int g, int b,int a){
        graphic.setColor(new Color(r,g,b,a));
    }
    
    public void setForegroundColor(Color c){
        graphic.setColor(c);
    }
    
    /**
     * Wait for a specified number of milliseconds before finishing.
     * This provides an easy way to specify a small delay which can be
     * used when producing animations.
     * @param  milliseconds  the number 
     */
    public void wait(int milliseconds)
    {
        try
        {
            Thread.sleep(milliseconds);
        } 
        catch (Exception e)
        {
           System.out.println(e); // ignoring exception at the moment--NÖ
        }
    }

    /**
     * Redraw ell shapes currently on the oCanvas.
     */
    private void redraw()
    {
        erase();
        for(Iterator i=objects.iterator(); i.hasNext(); ) {
			Object next=i.next();
			try{
            ((ShapeDescription)shapes.get(next)).draw(graphic);
			}catch(Exception e){
			//e.printStackTrace(System.out);
			}
			try{
            ((TextDescription)shapes.get(next)).draw(graphic);
			}catch(Exception e){
			//e.printStackTrace(System.out);
			}
        }
        oCanvas.repaint();
    }
       
    /**
     * Erase the whole oCanvas. (Does not repaint.)
     */
    private void erase()
    {
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = oCanvas.getSize();
        graphic.fill(new Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
    }
    
    protected String getTitle(){
        return title;
    }
    
    protected int getWidth(){
        return width;
    }
    
    protected int getHeight(){
        return height;
    }
    
    protected Color getColor(){
        return color;
    }

	public void setSize(int width, int height){
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		
		if(width<screenSize.getWidth() && height<screenSize.getHeight() && width>0 && height>0 ){
			setPreferredSize(new Dimension(width, height));
			pack();
		}
	}
	
	public void setSize(Dimension size){
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		
		if(size.getWidth()<screenSize.getWidth() && size.getHeight()<screenSize.getHeight() && size.getWidth()>0 && size.getHeight()>0 ){
			setPreferredSize(size);
			pack();
		}
	
	}
	
	protected void setPreferredSize(Dimension size){
		oCanvas.setPreferredSize(size);
	}
	
	protected void pack(){
		frame.pack();
	}
	
	public void setResizable(boolean bool){
		frame.setResizable(bool);
	}
	
	public boolean isResizable(){
		return frame.isResizable();
	}
	
	public void setMiddlePos(){
		frame.setLocationRelativeTo(null);
		//frame.setLocation(frame.getX()-frame.getWidth()/2,frame.getY()-frame.getHeight()/2);
	}
	
    /************************************************************************
     * Inner class oCanvasPane - the actual oCanvas component contained in the
     * oCanvas frame. This is essentially a JPanel with added capability to
     * refresh the image drawn on it.
     */
    public class oCanvasPane extends JPanel
    {
        public void paint(Graphics g)
        {
            g.drawImage(oCanvasImage, 0, 0, null);
        }
    }
    
    /************************************************************************
     * Inner class oCanvasPane - the actual oCanvas component contained in the
     * oCanvas frame. This is essentially a JPanel with added capability to
     * refresh the image drawn on it.
     */
    private class ShapeDescription
    {
        private Shape shape;
        private String colorString;
		private Color color;

        public ShapeDescription(Shape shape, String color)
        {
            this.shape = shape;
            colorString = color;
        }
		
		public ShapeDescription(Shape shape, Color color){
			this.shape=shape;
			this.color=color;
		}

        public void draw(Graphics2D graphic)
        {	
			try{
				setForegroundColor(colorString);
            } catch(Exception ignored){}
			
			try{
				setForegroundColor(color);
            } catch(Exception ignored){}
			
			graphic.fill(shape);
        }
    }
	
	private class TextDescription{
        private String text;
		private Font font;
		private int xPos;
        private int yPos;
		private Color color;


		public TextDescription(String text, Font font, int xPos, int yPos, Color color){
            this.text = text;
			this.font = font;
			this.xPos=xPos;
			this.yPos=yPos;
            this.color = color;
			//o.println("TextDescriptionColor: "+color);
        }
        public void draw(Graphics2D graphic){
			/*try{
				setForegroundColor(colorString);
            } catch(Exception ignored){}

			try{
				setForegroundColor(color);
            } catch(Exception ignored){}
			*/
			
			//System.out.println(color);
			//System.out.println(xPos);
			//System.out.println(yPos);
			
			graphic.setColor(color);
			graphic.setFont(font);
			graphic.drawString(text, xPos, yPos);
		}	
    }

}







 
    

