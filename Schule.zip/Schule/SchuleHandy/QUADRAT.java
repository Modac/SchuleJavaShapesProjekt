import java.awt.*;

/**
 * A square that can be manipulated and that draws itself on a canvas.
 * 
 */

public class QUADRAT
{
    private int groesse;
    private int xPosition;
    private int yPosition;
    private String farbe;
    private boolean istSichtbar;

    /**
     * Create a new square at default position with default color.
     */
    public QUADRAT()
    {
        groesse = 30;
        xPosition = 60;
        yPosition = 50;
        farbe = "red";
        istSichtbar = false;
    }
    
    public QUADRAT(int g, int x, int y, String f, boolean iS)
    {
        groesse = g;
        xPosition = x;
        yPosition = y;
        farbe = f;
        istSichtbar = iS;
    }

    /**
     * Make this square visible. If it was already visible, do nothing.
     */
    public void zeichne()
    {
        istSichtbar = true;
        draw();
    }
    
    /**
     * Make this square invisible. If it was already invisible, do nothing.
     */
    public void loesche()
    {
        erase();
        istSichtbar = false;
    }
    
    /**
     * Move the square a few pixels to the right.
     */
    public void verschiebeRechts()
    {
        verschiebeHorizontal(20);
    }

    /**
     * Move the square a few pixels to the left.
     */
    public void verschiebeLinks()
    {
        verschiebeHorizontal(-20);
    }

    /**
     * Move the square a few pixels up.
     */
    public void verschiebeOben()
    {
        verschiebeVertikal(-20);
    }

    /**
     * Move the square a few pixels down.
     */
    public void cherschiebeUnten()
    {
        verschiebeVertikal(20);
    }

    /**
     * Move the square horizontally by 'distance' pixels.
     */
    public void verschiebeHorizontal(int distanz)
    {
        erase();
        xPosition = xPosition + distanz;
        draw();
    }

    /**
     * Move the square vertically by 'distance' pixels.
     */
    public void verschiebeVertikal(int distanz)
    {
        erase();
        yPosition = yPosition + distanz;
        draw();
    }

    /**
     * Slowly move the square horizontally by 'distance' pixels.
     */
    public void langsamVerschiebenHorizontal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            xPosition = xPosition + delta;
            draw();
        }
    }

    /**
     * Slowly move the square vertically by 'distance' pixels.
     */
    public void langsamVerschiebenVertikal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            yPosition = yPosition + delta;
            draw();
        }
    }

    /**
     * Change the size to the new size (in pixels). Size must be >= 0.
     */
    public void aendereGroesse(int neueGroesse)
    {
        erase();
        groesse = neueGroesse;
        draw();
    }

    /**
     * Change the color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void aendereFarbe(String neueFarbe)
    {
        
        farbe = neueFarbe;
        draw();
    }

    /*
     * Draw the square with current specifications on screen.
     */
    private void draw()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, farbe,
                        new Rectangle(xPosition, yPosition, groesse, groesse));
            canvas.wait(10);
        }
    }

    /*
     * Erase the square on screen.
     */
    private void erase()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    public void setX(int xPosition){
        erase();
        this.xPosition=xPosition;
        draw();
	}
	
	public void setY(int yPosition){
	    erase();
	    this.yPosition=yPosition;
	    draw();
	}
	
	public void setPos(int xPosition, int yPosition){
	    erase();
	    this.xPosition=xPosition;
	    this.yPosition=yPosition;
	    draw();
	}
	
	public int getX(){
	    return xPosition;
	}
	
	public int getY(){
	    return yPosition;
	}
}