import java.awt.*;
import java.awt.geom.*;



public class KREIS
{
    private int durchmesser;
    private int xPosition;
    private int yPosition;
    private String farbe;
    private boolean istSichtbar;
    
    /**
     * Create a new circle at default position with default color.
     */
    public KREIS()
    {
        durchmesser = 30;
        xPosition = 20;
        yPosition = 60;
        farbe = "blue";
        istSichtbar = false;
    }

    /**
     * Make this circle visible. If it was already visible, do nothing.
     */
    public void zeichne()
    {
        istSichtbar = true;
        draw();
    }
    
    /**
     * Make this circle invisible. If it was already invisible, do nothing.
     */
    public void loesche()
    {
        erase();
        istSichtbar = false;
    }
    
    /**
     * Move the circle a few pixels to the right.
     */
    public void verschiebeRechts()
    {
        verschiebeHorizontal(20);
    }

    /**
     * Move the circle a few pixels to the left.
     */
    public void verschiebeLinks()
    {
        verschiebeHorizontal(-20);
    }

    /**
     * Move the circle a few pixels up.
     */
    public void verschiebeOben()
    {
        verschiebeVertikal(-20);
    }

    /**
     * Move the circle a few pixels down.
     */
    public void verschiebeUnten()
    {
        verschiebeVertikal(20);
    }

    /**
     * Move the circle horizontally by 'distance' pixels.
     */
    public void verschiebeHorizontal(int distanz)
    {
        erase();
        xPosition = xPosition + distanz;
        draw();
    }

    /**
     * Move the circle vertically by 'distance' pixels.
     */
    public void verschiebeVertikal(int distance)
    {
        erase();
        yPosition = yPosition + distance;
        draw();
    }

    /**
     * Slowly move the circle horizontally by 'distance' pixels.
     */
    public void langsamVerschiebenHorizontal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            xPosition = xPosition + delta;
            draw();
        }
    }

    /**
     * Slowly move the circle vertically by 'distance' pixels.
     */
    public void langsamVerschiebenVertikal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            yPosition = yPosition + delta;
            draw();
        }
    }

    /**
     * Change the size to the new size (in pixels). Size must be >= 0.
     */
    public void aendereGroesse(int neuerDurchmesser)
    {
        erase();
        durchmesser = neuerDurchmesser;
        draw();
    }

    /**
     * Change the color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void aendereFarbe(String neueFarbe)
    {
        farbe = neueFarbe;
        draw();
    }

    /*
     * Draw the circle with current specifications on screen.
     */
    private void draw()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, farbe, new Ellipse2D.Double(xPosition, yPosition, 
                                                          durchmesser,durchmesser));
            canvas.wait(10);
        }
    }

    /*
     * Erase the circle on screen.
     */
    private void erase()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    public void setX(int xPosition){
        erase();
        this.xPosition=xPosition;
        draw();
    }
    
    public void setY(int yPosition){
        erase();
        this.yPosition=yPosition;
        draw();
    }
    
    public void setPos(int xPosition, int yPosition){
        erase();
        this.xPosition=xPosition;
        this.yPosition=yPosition;
        draw();
    }
    
    public int getDurchmesser(){
        return durchmesser;
    }
    
    public int getX(){
	    return xPosition;
	}
	
	public int getY(){
	    return yPosition;
	}
}
