import java.awt.*;

/**
 * A triangle that can be manipulated and that draws itself on a canvas.
 * 
 */

public class DREIECK
{
     int hoehe;
     int breite;
	 int xPosition;
	 int yPosition;
	 String farbe;
	 boolean istSichtbar;

    /**
     * Create a new triangle at default position with default color.
     */
    public DREIECK()
    {
		hoehe = 30;
		breite = 40;
		xPosition = 50;
		yPosition = 15;
		farbe = "green";
		istSichtbar = false;
    }

	/**
	 * Make this triangle visible. If it was already visible, do nothing.
	 */
	public void zeichne()
	{
		istSichtbar = true;
		draw();
	}
	
	/**
	 * Make this triangle invisible. If it was already invisible, do nothing.
	 */
	public void loesche()
	{
		erase();
		istSichtbar = false;
	}
	
    /**
     * Move the triangle a few pixels to the right.
     */
   public void verschiebeRechts()
    {
		verschiebeHorizontal(20);
    }

    /**
     * Move the circle a few pixels to the left.
     */
    public void verschiebeLinks()
    {
		verschiebeHorizontal(-20);
    }

    /**
     * Move the circle a few pixels up.
     */
    public void verschiebeOben()
    {
		verschiebeVertikal(-20);
    }

    /**
     * Move the circle a few pixels down.
     */
    public void verschiebeUnten()
    {
		verschiebeVertikal(20);
    }

   /**
     * Move the circle horizontally by 'distance' pixels.
     */
    public void verschiebeHorizontal(int distanz)
    {
		erase();
		xPosition = xPosition + distanz;
		draw();
    }

    /**
     * Move the circle vertically by 'distance' pixels.
     */
    public void verschiebeVertikal(int distance)
    {
		erase();
		yPosition = yPosition + distance;
		draw();
    }

    /**
     * Slowly move the circle horizontally by 'distance' pixels.
     */
    public void langsamVerschiebenHorizontal(int distanz)
    {
		int delta;

		if(distanz < 0) 
		{
			delta = -1;
			distanz = -distanz;
		}
		else 
		{
			delta = 1;
		}

		for(int i = 0; i < distanz; i++)
		{
			xPosition = xPosition + delta;
			draw();
		}
    }

    /**
     * Slowly move the circle vertically by 'distance' pixels.
     */
    public void langsamVerschiebenVertikal(int distanz)
    {
		int delta;

		if(distanz < 0) 
		{
			delta = -1;
			distanz = -distanz;
		}
		else 
		{
			delta = 1;
		}

		for(int i = 0; i < distanz; i++)
		{
			yPosition = yPosition + delta;
			draw();
		}
    }

    /**
     * Change the size to the new size (in pixels). Size must be >= 0.
     */
    public void setSize(int neueHoehe, int neueBreite)
    {
		erase();
		hoehe = neueHoehe;
		breite = neueBreite;
		draw();
    }

   public void aendereFarbe(String neueFarbe)
    {
		farbe = neueFarbe;
		draw();
    }

	/*
	 * Draw the circle with current specifications on screen.
	 */
	private void draw()
	{
		if(istSichtbar) {
			Canvas canvas = Canvas.getCanvas();
            int[] xpoints = { xPosition, xPosition + (breite/2), xPosition - (breite/2) };
            int[] ypoints = { yPosition, yPosition + hoehe, yPosition + hoehe };
            canvas.draw(this, farbe, new Polygon(xpoints, ypoints, 3));
            canvas.wait(10);
		}
	}

	/*
	 * Erase the circle on screen.
	 */
	private void erase()
	{
		if(istSichtbar) {
			Canvas canvas = Canvas.getCanvas();
			canvas.erase(this);
		}
	}
	
	public void setX(int xPosition){
        erase();
        this.xPosition=xPosition;
        draw();
	}
	
	public void setY(int yPosition){
	    erase();
	    this.yPosition=yPosition;
	    draw();
	}
	
	public void setPos(int xPosition, int yPosition){
	    erase();
	    this.xPosition=xPosition;
	    this.yPosition=yPosition;
	    draw();
	}
	
	public int getX(){
	    return xPosition;
	}
	
	public int getY(){
	    return yPosition;
	}
}