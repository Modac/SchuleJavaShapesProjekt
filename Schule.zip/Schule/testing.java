import java.io.PrintStream;

public class testing{
    private static PrintStream o=System.out;
    public static void main(String[] as){
        int xPos[]=new int[]{2,2,4};
        int xpos=20;
        
        try{
			for(int i=0;i<xPos.length;i++){
				o.print(i+1+") "+xPos[i]+"\n");
			}
		}catch(Exception e){}
		o.println();
        
        int[] temp;
			try{
				temp= new int[xPos.length+1];
				for(int i=0; i<xPos.length;i++){
					temp[i]=xPos[i];
				}
				temp[xPos.length]=xpos;
			} catch(NullPointerException e){
				temp=new int[]{xpos};
			}
				
			xPos=temp;
        
        try{
			for(int i=0;i<xPos.length;i++){
				o.print(i+1+") "+xPos[i]+"\n");
			}
		}catch(Exception e){}
		o.println();
        /*for(int i=0;i<20;i++){
            o.print(i/2+" | ");
        }*/
    }
}
