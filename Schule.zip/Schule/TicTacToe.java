import java.io.PrintStream;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.font.GlyphVector;
import java.awt.Font;
import java.awt.FontMetrics;

public class TicTacToe implements MouseListener {
    private static PrintStream o=System.out;
    
    KREUZ[][] kreuze;
    RING[][] ringe;
    xRECHTECK[] grenzen;
    xRECHTECK[][] felder;
    oCanvas canvas;
    int pressedX, pressedY;
    int zug;
	int fieldSize;
	int borderWidth;
	int marginWidth;
	int fieldNum;
    
    public TicTacToe(){
        
		fieldSize=100;
		fieldNum=3;
		borderWidth=5;
		marginWidth=10;
		
        kreuze=new KREUZ[fieldNum][fieldNum];
        ringe=new RING[fieldNum][fieldNum];
        felder=new xRECHTECK[fieldNum][fieldNum];
        grenzen=new xRECHTECK[(fieldNum-1)*2];
		
        
        canvas=new oCanvas("TicTacToe", fieldSize*fieldNum+borderWidth*(fieldNum-1)+marginWidth*2, fieldSize*fieldNum+borderWidth*(fieldNum-1)+marginWidth*2, Color.white);
        canvas.setResizable(false);
        canvas.wait(10);
        canvas.pack();
		canvas.setMiddlePos();
        
        //o.println(felder.length+"");
        //o.println(felder[0].length+"[]");
        
        for(int i=0;i<felder.length;i++){
            int x=i*(fieldSize+borderWidth)+marginWidth; // xPos = i * (width of fields + width of borders) + environmental border width
            for(int m=0;m<felder[i].length;m++){
                int y=m*(fieldSize+borderWidth)+marginWidth; // same as for xPos
                kreuze[i][m]=new KREUZ(fieldSize, 10, x, y, Color.RED);
                ringe[i][m]=new RING(fieldSize-1, 10, x, y, "blue");
                felder[i][m]=new xRECHTECK(fieldSize, fieldSize, x, y, 0, new Color(0,0,0,0));
            }
        }
        for(int i=0;i<grenzen.length;i++){				   //	 |														|									 |		|	 |
            if(i%2==1) grenzen[i]=new xRECHTECK(borderWidth, fieldNum*(fieldSize+borderWidth)-borderWidth, (i/2+1)*(fieldSize+borderWidth)+borderWidth, marginWidth, 0, Color.black);						//	public xRECHTECK(int breite,int hoehe, int xPos, int yPos, int winkel, String farbe)
            else grenzen[i]=new xRECHTECK(fieldNum*(fieldSize+borderWidth)-borderWidth, borderWidth, marginWidth, (i/2+1)*(fieldSize+borderWidth)+borderWidth, 0 ,Color.black);
        }																	//													   |	|	  |									|	 |
        
        canvas.getoCanvasPane().addMouseListener(this);
    }
    
    public void init(){
        canvas.setVisible(true);
        for(int i=0;i<felder.length;i++){
            for(int m=0;m<felder[i].length;m++){
                felder[i][m].zeichne(canvas);
            }
        }
        for(int i=0;i<grenzen.length;i++){
            grenzen[i].zeichne(canvas);
        }
		canvas.getoCanvasPane().removeMouseListener(this);
		canvas.getoCanvasPane().addMouseListener(this);
    }
    
    /*public void draw(){
        canvas.setVisible(true);
        for(int i=0;i<felder.length;i++){
            for(int m=0;m<felder[i].length;m++){
                kreuze[i][m].zeichne(canvas);
                ringe[i][m].zeichne(canvas);
                felder[i][m].zeichne(canvas);
            }
        }
        
    }*/
    
    private void checkArea(int x, int y){
        for(int i=0;i<felder.length;i++){
            for(int m=0;m<felder[i].length;m++){
            //o.println(( kreuze[i][m].isVisible() || ringe[i][m].isVisible() ));
                if( !(kreuze[i][m].isVisible() || ringe[i][m].isVisible()) && felder[i][m].contains(pressedX, pressedY) && felder[i][m].contains(x,y) ){
                    //if( !(kreuze[i][m].isVisible() || ringe[i][m].isVisible()) ){
                        zug++;
                        if  (zug%2==1)kreuze[i][m].zeichne(canvas);
                        else ringe[i][m].zeichne(canvas);
                        
						try{
							isSomeoneWinner();
						}catch(NoSuchFieldException e){}
                        break;
                    //}
                }
            }
        }
        //o.println("-----");
    }
	
	private void isSomeoneWinner() throws NoSuchFieldException{
		WINNER winner=null;
		boolean won=false;
		if(checkWin(kreuze).isWinner()) {
		    winner=checkWin(kreuze);
		    won=true;
			
		}
		else if(checkWin(ringe).isWinner()) {
		    winner=checkWin(ringe);
		    won=true;
		}
		if(winner!=null){
			try{
				while((canvas.getoCanvasPane().getMouseListeners())[0]==this){				//	Not necessary any more
					canvas.getoCanvasPane().removeMouseListener(this);									//	Accidentally added MouseListener two times
					//o.println("MouseListener released.");																	//	Modac©
				}
			}catch(ArrayIndexOutOfBoundsException e){}
			
			drawWinnerLine(winner.getXPos()[0],winner.getYPos()[0],winner.getXPos()[winner.getXPos().length-1],winner.getYPos()[winner.getYPos().length-1]);
			
			if(won && winner.getZeichen()==kreuze){
				String text="Kreuze hat gewonnen";
				Font defaultFont = new Font("Sans Serif", Font.PLAIN, 30);
				FontMetrics fontMetrics = canvas.getoCanvasPane().getFontMetrics(defaultFont);
				int width = fontMetrics.stringWidth(text);
				int height = fontMetrics.getHeight();
				drawString(text, canvas.getWidth()/2-width/2, canvas.getHeight()/2, "Sans Serif", Font.PLAIN, 30, Color.green.darker());																			//	 drawString(String text, int x, int y, String fname, int fstyle, int fsize, Color color){
			}
			if(won && winner.getZeichen()==ringe){
				String text="Ringe hat gewonnen";
				Font defaultFont = new Font("Sans Serif", Font.PLAIN, 30);
				FontMetrics fontMetrics = canvas.getoCanvasPane().getFontMetrics(defaultFont);
				int width = fontMetrics.stringWidth(text);
				int height = fontMetrics.getHeight();
				drawString(text, canvas.getWidth()/2-width/2, canvas.getHeight()/2, "Sans Serif", Font.PLAIN, 30, Color.green.darker());		
			}
		
			// for(int i=0;i<winner.getXPos().length;i++){
				// winner.printPos();
			// }
			
		}
	}
    
    private WINNER checkWin(Zeichen[][] zeichen){
        WINNER winner=new WINNER(zeichen, null, null, false);
		for(int i=0;i<felder.length;i++){
		winner.isWinner(true);
			winner.setPos(null, null);
			for(int m=0;m<felder.length;m++){
				if(winner.isWinner()){
					if(zeichen[i][m].isVisible()) {
					
						winner.isWinner(true);
						winner.addXPos(i);
						winner.addYPos(m);
						//o.print(winner.getZeichen().getClass().getSimpleName());
						//winner.printPos();
					}
					else winner.isWinner(false);
					//o.println("i|m: "+i+"|"+m+" is Winning: "+isWinning+" isVisible: "+zeichen[i][m].isVisible());
				}
			}
			if(winner.isWinner()) return winner;
		}
		for(int m=0;m<felder.length;m++){
			winner.isWinner(true);
			winner.setPos(null, null);
			for(int i=0;i<felder.length;i++){
				if(winner.isWinner()){
					if(zeichen[i][m].isVisible()){
						
						winner.isWinner(true);
						winner.addXPos(i);
						winner.addYPos(m);
						//o.print(winner.getZeichen().getClass().getSimpleName());
						//winner.printPos();
					}
					else winner.isWinner(false);
				}
			}
			if(winner.isWinner()) return winner;
		}
		
		// In Queue for Improvment // IQfI
		
		if(zeichen[0][0].isVisible() && zeichen[1][1].isVisible() && zeichen[2][2].isVisible()) return new WINNER(zeichen, new int[]{0,1,2}, new int[]{0,1,2}, true );
		if(zeichen[2][0].isVisible() && zeichen[1][1].isVisible() && zeichen[0][2].isVisible()) return new WINNER(zeichen, new int[]{2,1,0}, new int[]{0,1,2}, true );

		return new WINNER(zeichen, new int[]{0}, new int[]{0}, false );
    }
    
    public void newGame(){
        for(int i=0;i<felder.length;i++){
            for(int m=0;m<felder[i].length;m++){
                kreuze[i][m].loesche(canvas);
                ringe[i][m].loesche(canvas);
            }
        }
		zug=0;
		canvas.setVisible(true);
		canvas.getoCanvasPane().removeMouseListener(this);
		canvas.getoCanvasPane().addMouseListener(this);
    }
	
	
	private void drawString(String text, int x, int y, String fname, int fstyle, int fsize, Color color){
		Font font = new Font(fname, fstyle, fsize);
		TEXT textShape=new TEXT(text, font.getStyle(), font.getSize(), x, y, color, canvas);
		textShape.zeichne();
	}
    
	private void drawWinnerLine(int firstXPos, int firstYPos, int lastXPos, int lastYPos){
		
		
	}
	
	
    public void mouseClicked(MouseEvent e){
        //o.println("Mouse Clicked at: "+ e.getX()+" / "+e.getY());
    }
    
    public void mouseEntered(MouseEvent e){
        
    }
    
    public void mouseExited(MouseEvent e){
        
    }
    
    public void mousePressed(MouseEvent e){
	
			//o.println("Mouse Pressed at: "+ e.getX()+" / "+e.getY());
			
        pressedX=e.getX();
        pressedY=e.getY();
		
    }
    
    public void mouseReleased(MouseEvent e){
        //o.println("Mouse Released at: "+ e.getX()+" / "+e.getY());
		checkArea(e.getX(), e.getY());
	}
	
	private class WINNER{
		private Zeichen[][] zeichen;
		private int[] xPos, yPos;
		private boolean isWinner;
		
		public WINNER(Zeichen[][] zeichen, int[] xPos, int[] yPos, boolean isWinner){
			this.zeichen=zeichen;
			this.xPos=xPos;
			this.yPos=yPos;
			this.isWinner=isWinner;
		}
		
		public WINNER(Zeichen[][] zeichen, boolean isWinner){
			this.zeichen=zeichen;
			this.isWinner=isWinner;
		}
		
		public Zeichen[][] getZeichen(){
			return zeichen;
		}
		
		public int[] getXPos(){
			return xPos;
		}
		
		public int[] getYPos(){
			return yPos;
		}
		
		public boolean isWinner(){
			return isWinner;
		}
		
		public void isWinner(boolean isWinner){
			this.isWinner=isWinner;
		}
		
		public void setXPos(int[] xPos){
			this.xPos=xPos;
		}
		
		public void setYPos(int[] yPos){
			this.yPos=yPos;
		}
		
		public void setPos(int[] xPos, int[] yPos){
			this.xPos=xPos;
			this.yPos=yPos;
		}
		
		public void addXPos(int xpos){
			int[] temp;
			try{
				temp= new int[xPos.length+1];
				for(int i=0; i<xPos.length;i++){
					temp[i]=xPos[i];
				}
				temp[xPos.length]=xpos;
			} catch(NullPointerException e){
				temp=new int[]{xpos};
			}
				
			xPos=temp;
		}
		
		public void addYPos(int ypos){
		    int[] temp;
			try{
				temp= new int[yPos.length+1];
				for(int i=0; i<yPos.length;i++){
					temp[i]=yPos[i];
				}
				temp[yPos.length]=ypos;
			} catch(NullPointerException e){
				temp=new int[]{ypos};
			}
			
			yPos=temp;
			
		}
		
		public void printPos(){
		try{
			for(int i=0;i<xPos.length;i++){
				o.print(i+1+") "+xPos[i]+"|"+yPos[i]+"\n");
			}
		}catch(Exception e){}
		o.println();
		}
	}
}
