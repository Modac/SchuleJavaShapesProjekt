import java.io.PrintStream;
import java.awt.Color;
import java.awt.font.GlyphVector;
import java.awt.Font;
import java.awt.Shape;
import java.lang.reflect.Field;

public class TEXT{
	private static PrintStream o=System.out;
	
	private String text;
	private Font font;
	private Color color;
	private int xPos,yPos;
	private boolean istSichtbar;
	private oCanvas canvas;
	
	public TEXT(){
		font = new Font("TextFont["+this.toString()+"]", Font.PLAIN, 20);
		xPos=50;
		yPos=50;
		color=Color.black;
		text="Hallo";
		istSichtbar=false;
		canvas=null;
		
	}
	
	public TEXT(String text, int style, int size, int xPos, int yPos, Color color, oCanvas canvas){
		this.font = new Font("TextFont["+this.toString()+"]",style, size);
		this.text = text;
		this.xPos=xPos;
		this.yPos=yPos;
		this.color=color;
		istSichtbar=false;
		this.canvas=canvas;

	}
	
	public void zeichne(){
		
		istSichtbar=true;
		draw();
	}
	
	/*public void zeichne(oCanvas canvas){
		
		draw(canvas);
		istSichtbar=true;
	}*/
	
	public void loesche(){
		istSichtbar=false;
		erase();
	}
	
	
	

public void verschiebeRechts()
    {
        verschiebeHorizontal(20);
    }

    /**
     * Move the square a few pixels to the left.
     */
    public void verschiebeLinks()
    {
        verschiebeHorizontal(-20);
    }

    /**
     * Move the square a few pixels up.
     */
    public void verschiebeOben()
    {
        verschiebeVertikal(-20);
    }

    /**
     * Move the square a few pixels down.
     */
    public void verschiebeUnten()
    {
        verschiebeVertikal(20);
    }

    /**
     * Move the square horizontally by 'distance' pixels.
     */
    public void verschiebeHorizontal(int distanz)
    {
        erase();
        xPos = xPos + distanz;
        draw();
    }

    /**
     * Move the square vertically by 'distance' pixels.
     */
    public void verschiebeVertikal(int distanz)
    {
        erase();
        yPos = yPos + distanz;
        draw();
    }

    /**
     * Slowly move the square horizontally by 'distance' pixels.
     */
    public void langsamVerschiebenHorizontal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            xPos = xPos + delta;
            draw();
        }
    }

    /**
     * Slowly move the square vertically by 'distance' pixels.
     */
    public void langsamVerschiebenVertikal(int distanz)
    {
        int delta;

        if(distanz < 0) 
        {
            delta = -1;
            distanz = -distanz;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < distanz; i++)
        {
            yPos = yPos + delta;
            draw();
        }
    }

    /**
     * Change the size to the new size (in pixels). Size must be >= 0.
     */
    public void aendereGroesse(int neueGroesse)
    {
        erase();
        font = font.deriveFont((float)neueGroesse);
        draw();
    }

    /**
     * Change the color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void aendereFarbe(String neueFarbe)
    {
        
        try {
            Field field = Class.forName("java.awt.Color").getField(neueFarbe);
            color = (Color)field.get(null);
        } catch (Exception e) {
            color = Color.black; // Not defined
        }
        draw();
		o.println("AendereFarbe: "+color);
    }

    /*
     * Draw the square with current specifications on screen.
     */
    private void draw(){
		if(canvas==null){
			if(istSichtbar) {
				Canvas tcanvas = Canvas.getCanvas();
				//o.println(color);
				tcanvas.drawText(this,  text, font, xPos, yPos, color);
				tcanvas.wait(10);
			}
		} else{
			if(istSichtbar) {
				canvas.drawText(this,  text, font, xPos, yPos, color);
				canvas.wait(10); 
			}
		}
    }
	
	 /*private void draw(oCanvas canvas){
        if(istSichtbar) {
            canvas.drawText(this, text, font, xPos, yPos, color);
            canvas.wait(10);
        }
    }*/

    /*
     * Erase the square on screen.
     */
    private void erase()
    {
        if(istSichtbar) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
	
	private void erase(oCanvas canvas)
    {
        if(istSichtbar) {
            canvas.erase(this);
        }
    }
    
    public void setX(int xPos){
        erase();
        this.xPos=xPos;
        draw();
	}
	
	public void setY(int yPos){
	    erase();
	    this.yPos=yPos;
	    draw();
	}
	
	public void setColor(Color color){
		erase();
		this.color=color;
		draw();
	}
	
	public void setPos(int xPos, int yPos){
	    erase();
	    this.xPos=xPos;
	    this.yPos=yPos;
	    draw();
	}
	
	public int getX(){
	    return xPos;
	}
	
	public int getY(){
	    return yPos;
	}
	
	public boolean isVisible(){
		return istSichtbar;
	}
}
