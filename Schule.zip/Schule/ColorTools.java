import java.awt.Color;

public class ColorTools{

	public static Color getRandomColor(){
		int r,g,b;
		r=(int) (Math.random()*255);
		g=(int) (Math.random()*255);
		b=(int) (Math.random()*255);
		
		return new Color(r,g,b);
	}
	
	public static Color getRgbRandomColor(){
		int rgb;
		rgb=(int) (Math.random()*16777215);
		return new Color(rgb);
	}
	
	public static Color negativeColor(Color c){
		int r,g,b;
		r=255-c.getRed();
		g=255-c.getGreen();
		b=255-c.getBlue();
		
		return new Color(r,g,b);
	}
	
	public static Color getColor(){
		int randm=(int)(Math.random()*5);
		switch (randm){
			case 0:
				return Color.blue;
			case 1:
				return Color.red;
			case 2:
				return Color.green;
			case 3:
				return Color.yellow;
			case 4:
				return Color.orange;
			case 5:
				return Color.pink;
			default:
				return Color.magenta;
		}
		
		
	}
	
	public static Color getFullColor(){
	    return new Color(50,50,50,255);
	}
	
	public static Color getHalfColor(){
	    return new Color(50,50,50,100);
	}
	
	public static Color getNoColor(){
	    return new Color(50,50,50,0);
	}
	
}